import React from "react";
import "./App.css";

function App() {
  return (
    <div className="mainContainer">
      <h3 className="title">Todo App</h3>
    </div>
  );
}

export default App;
