import {
  ADD_TODO,
  DELETE_TODO,
  UPDATE_TODO,
} from "../../Utils/reduxActionTypeConst";

const intialState = {
  todos: [],
  loading: false,
};

export const todoReducer = (state = intialState, action) => {
  switch (action.type) {
    case ADD_TODO:
      return {
        ...state,
      };
    case UPDATE_TODO:
      return {
        ...state,
      };
    case DELETE_TODO:
      return {
        ...state,
      };
    default:
      return state;
  }
};
